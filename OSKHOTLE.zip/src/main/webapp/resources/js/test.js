alert('잘 된다.'); 


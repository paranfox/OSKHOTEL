package com.osk.project.domain;

public class LodgingVO { // 숙소 종류

} // LodgingVO
